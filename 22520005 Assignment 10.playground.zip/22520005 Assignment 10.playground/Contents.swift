import UIKit

var greeting = "Hello, playground"
// 1. Yes, it's possible for the user to input text that cannot be directly converted to the desired type.

// 2. Simulating user input error
let userInputAge: String = "34e"
// Attempting to convert String to Int
// Error: Cannot convert value of type 'String' to specified type 'Int'
// let userAge: Int = Int(userInputAge)

// 3. Declaring userAge as an optional Int
var userAge: Int? = Int(userInputAge)
// The value of userAge is nil because the string "34e" cannot be converted to an integer.

// 4. Fixing the typo
let userInputAgeFixed: String = "34"
userAge = Int(userInputAgeFixed)
print(userAge as Any) // Prints: Optional(34)

// 5. Unwrapping userAge using force unwrap operator
print(userAge!) // Prints: 34

// 6. Declaring and printing heartRate with nil value
var heartRate: Int? = nil
print(heartRate as Any) // Prints: nil

// 7. Updating heartRate value and printing
heartRate = 74
print(heartRate as Any) // Prints: Optional(74)

// 8. Calculating average heart rate
let oldHR1 = 80
let oldHR2 = 76
let oldHR3 = 79
let oldHR4 = 70
let hrAverage: Int = (oldHR1 + oldHR2 + oldHR3 + oldHR4 + (heartRate ?? 0)) / 5
print(hrAverage) // Prints: 75

// 9. Safely unwrapping heartRate and calculating average heart rate
if let heartRateValue = heartRate {
    let hrAverage: Int = (oldHR1 + oldHR2 + oldHR3 + oldHR4 + heartRateValue) / 5
    print(hrAverage) // Prints: 75
} else {
    let hrAverage: Int = (oldHR1 + oldHR2 + oldHR3 + oldHR4) / 4
    print(hrAverage) // Prints: 76
}

// 10. Creating a collection of type [Any]
let collection: [Any] = [3.14, 42, "Hello", true]
print(collection)

// 11. Looping through the collection and printing values
for item in collection {
    if let intValue = item as? Int {
        print("The integer has a value of \(intValue)")
    } else if let doubleValue = item as? Double {
        print("The double has a value of \(doubleValue)")
    } else if let stringValue = item as? String {
        print("The string has a value of \(stringValue)")
    } else if let boolValue = item as? Bool {
        print("The boolean has a value of \(boolValue)")
    }
}

// 12. Creating a [String: Any] dictionary
let dictionary: [String: Any] = ["pi": 3.14, "answer": 42, "greeting": "Hello", "flag": true]
// Printing key/value pairs
for (key, value) in dictionary {
    print("\(key): \(value)")
}

// 13. Calculating total based on values in dictionary
var total: Double = 0
for (_, value) in dictionary {
    if let intValue = value as? Int {
        total += Double(intValue)
    } else if let doubleValue = value as? Double {
        total += doubleValue
    } else if let stringValue = value as? String {
        total += 1
    } else if let boolValue = value as? Bool {
        total += boolValue ? 2 : -3
    }
}
print(total)

// 14. Calculating total by attempting to convert strings to numbers
var total2: Double = 0
for item in collection {
    if let intValue = item as? Int {
        total2 += Double(intValue)
    } else if let doubleValue = item as? Double {
        total2 += doubleValue
    } else if let stringValue = item as? String, let numberValue = Double(stringValue) {
        total2 += numberValue
    }
}
print(total2)

// 15. Provided class definitions and workouts array
class Workout {
    let time: Double
    let distance: Double
    
    init(time: Double, distance: Double) {
        self.time = time
        self.distance = distance
    }
}

class Run: Workout {
    let cadence: Double
    
    init(cadence: Double, time: Double, distance: Double) {
        self.cadence = cadence
        super.init(time: time, distance: distance)
    }
}

class Swim: Workout {
    let stroke: String
    
    init(stroke: String, time: Double, distance: Double) {
        self.stroke = stroke
        super.init(time: time, distance: distance)
    }
}

var workouts: [Workout] = [
    Run(cadence: 80, time: 1200, distance: 4000),
    Swim(stroke: "Freestyle", time: 32.1, distance: 50),
    Swim(stroke: "Butterfly", time: 36.8, distance: 50),
    Swim(stroke: "Freestyle", time: 523.6, distance: 500),
    Run(cadence: 90, time: 358.9, distance: 1600)
]

// 16. Defining functions to describe workouts
func describeRun(runningWorkout: Run) {
    print("Run: Cadence \(runningWorkout.cadence) steps per minute, Time \(runningWorkout.time) seconds, Distance \(runningWorkout.distance) meters")
}

func describeSwim(swimmingWorkout: Swim) {
    print("Swim: Stroke \(swimmingWorkout.stroke), Time \(swimmingWorkout.time) seconds, Distance \(swimmingWorkout.distance) meters")
}

// 17. Looping through workouts and describing them
for workout in workouts {
    if let run = workout as? Run {
        describeRun(runningWorkout: run)
    } else if let swim = workout as? Swim {
        describeSwim(swimmingWorkout: swim)
    }
}
