//PRN: 22520005
//Name: Aftab I. Bhadgaonkar
//Batch: T6

import UIKit

print ("I have learned the following:")
print("What features make Swift a modern and safe language")
print("How to use the Swift REPL in Terminal")
print("How to use playgrounds to make writing Swift fun and simple","\n")

//1. Now print your own phrases to the console. Pick one of your favorite songs. Use your knowledgeof the `print` function to display the song title and artist.
let song_title = "On My Way"
let artist = "Alan Walkar"

print("Now playing:", song_title, "by", artist,"\n")

//2. Use multiple `print` functions to write out some of the lyrics to the song.
print("I'm sorry but, don't wanna talk")
print("I need a moment before I go, it's nothing personal")
print("I draw the blinds, they don't need to see me cry")
print("Cause even if they understand, they don't understand","\n")

//3. Declare a constant called `friends` to represent the number of friends you have on social media. Give it a value between 50 and 1000. Print out the value by referencing your constant.
let friends: Int = 230

// Print out the value of the constant
print("Number of friends on social media: \(friends)","\n")

//4. Now assume you go through and remove a lot of your friends that aren't active on social media. Update your `friends` constant to a lower number than it currently is between 1 and 900.
//friends: Int = 250

//5. Does the above code compile? Why not? Print your explanation to the console using the `print` function. Go back and delete your line of code that updates the `friend` constant to  lower number so that the playground will compile properly.
print("Error: Cannot reassign a value to a constant ('let'). Use 'var' for mutable variables.","\n")

//6. Now pretend you just had a birthday, and update the `age` variable accordingly. Print `age` to the console.
var age = 25 // Initial age

print("Before birthday: \(age)")

age += 1

print("After birthday: \(age)","\n")

//7.
var myDouble: Double = 1.1

// Print out the initial value
print("Initial value: \(myDouble)")

myDouble = 2.2
print("After updating to 2.2: \(myDouble)")

myDouble = 3.3
print("After updating to 3.3: \(myDouble)")

myDouble = 4.4
print("After updating to 4.4: \(myDouble)","\n")

//8. Create a boolean variable and set it to `true`. Print the variable, then assign it a value of `false`, and print it again.
var myVar: Bool = true
print("Before value of myVar :\(myVar)","\n")
myVar = false;
print("After value of myVar :\(myVar)","\n")

//9.Create two variables, one with a value of 0, the other with a value of 0.0. Try to assign the second variable to the first, and you will receive an error. Add the necessary type annotation that will allow the second variable to be assigned to the first.
var intValue: Int = 0
var doubleValue: Double = 0.0

// This line will result in a compilation error
print("intValue = doubleValue : This declaration generates error that we cannot assign value of type Double to type Int")

intValue = Int(doubleValue)

print("intValue: \(intValue)")
print("doubleValue: \(doubleValue)","\n")

//10.Create a variable integer with a value of 1,000,000,000, ensuring that you format it so it is more readable (i.e. it's hard to read 1000000000, so make it easier to read).
var large_number = 1000000000
print("Before : ",large_number)

large_number = 1_000_000_000
print("After : ",large_number,"\n")

//11.Your fitness tracking app needs to know goal number of steps per day. Create a constant `goalSteps` and set it to 10000.
let goalSteps = 10000

//12.Use two `print` functions to print two separate lines to the console. The first line should say "Your step goal for the day is:", and the second line should print the value of `goalSteps` by referencing your constant.

print("Your step goal for the day is:")
print(goalSteps)

//13. Declare a variable `schooling` and set it to the number of years of school that you have completed. Print `schooling` to the console.
var schooling = 10
print("Years of schooling completed: \(schooling)","\n")

//14. Now imagine you just completed an additional year of school, and update the `schooling` variable accordingly. Print `schooling` to the console.
schooling += 2 // Adding an additional year

print("Updated years of schooling completed: \(schooling)")

//15. Does the above code compile? Why is this different than trying to update a constant? Print your explanation to the console using the `print` function.
// Explanation
print("Explanation: Yes, the above code compiled successfully because variables can be updated (mutated) because 'schooling' is declared as a variable.","\n")

//16. Create a variable called `steps` that will keep track of the number of steps you take throughout the day. Set its initial value to 0 to represent the step count first thing in the morning. Print `steps` to the console.
var steps = 0
print("Initial step count: \(steps)")

//17.Now assume the tracker has been keeping track of steps all morning, and you want to show the user the latest step count. Update `steps` to be 2000. Print `steps` to the console. Then print "Good job! You're well on your way to your daily goal."
steps = 2000
print("Latest step count: \(steps)")

print("Good job! You're well on your way to your daily goal.","\n")

/*18. Imagine you're creating a simple photo sharing app. You want to keep track of the following metrics for each post:
- Number of likes: the number of likes that a photo has received
- Number of comments: the number of comments other users have left on the photo
- Year created: The year the post was created
- Month created: The month the post was created represented by a number between 1 and 12 - Day created: The day of the month the post was created */

//19. For each of the metrics above, declare either a constant or a variable and assign it a value corresponding to a hypothetical post. Be sure to use proper naming conventions.

var numberOfLikes = 2200
var numberOfComments = 500
var yearCreated = 2024
var monthCreated = 1
var dayCreated = 18

/*20.There are all sorts of things that a fitness tracking app needs to keep track of in order to display the right information to the user. Similar to the last exercise, declare either a constant or a variable for each of the following items, and assign each a sensible value. Be sure to use proper naming conventions.
- Name: The user's name
- Age: The user's age
- Number of steps taken today: The number of steps that a user has taken today - Goal number of steps: The user's goal for number of steps to take each day
- Average heart rate: The user's average heart rate over the last 24 hours */

//21. Now go back and add a line after each constant or variable declaration. On those lines, print a statement explaining why you chose to declare the piece of information as a constant or variable.

// User Information
let userName = "Aftab Bhadgaonkar"
print("User Name: \(userName)")

let userAge = 20
print("User Age: \(userAge)")

var stepsTakenToday = 8500
print("Steps taken today: \(stepsTakenToday)")

let goalStep = 10000
print("Goal number of steps: \(goalSteps)")

var averageHeartRate = 75
print("Average heart rate: \(averageHeartRate)","\n")
