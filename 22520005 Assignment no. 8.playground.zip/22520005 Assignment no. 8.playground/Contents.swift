// Name: Aftab Bhadgaonkar
// PRN: 22520005
// Batch: T6


// 1. Spaceship class
class Spaceship {
    var name: String
    var health: Int
    var position: Int
    
    init(name: String = "", health: Int = 0, position: Int = 0) {
        self.name = name
        self.health = health
        self.position = position
    }
    
    func moveLeft() {
        position -= 1
    }
    
    func moveRight() {
        position += 1
    }
    
    func wasHit() {
        health -= 5
        if health <= 0 {
            print("Sorry, your ship was hit one too many times. Do you want to play again?")
        }
    }
}

// 2. Create falcon instance
let falcon0 = Spaceship(name: "Falcon")

// 3. Move falcon
falcon0.moveLeft()
print("Falcon's position after moving left once:", falcon0.position)

//falcon0.moveLeft()
//print("Falcon's position after moving left twice:", falcon0.position)
//
//falcon0.moveRight()
//print("Falcon's position after moving right once:", falcon0.position)
//
//// 4. Hit falcon
//falcon0.wasHit()
//print("Falcon's health after being hit:", falcon0.health)

// 6. Fighter class
class Fighter: Spaceship {
    var weapon: String
    var remainingFirePower: Int
    
    init(name: String = "", health: Int = 0, position: Int = 0, weapon: String = "", remainingFirePower: Int = 5) {
        self.weapon = weapon
        self.remainingFirePower = remainingFirePower
        super.init(name: name, health: health, position: position)
    }
    
    func fire() {
        if remainingFirePower > 0 {
            remainingFirePower -= 1
        } else {
            print("You have no more fire power.")
        }
    }
}

// 7. Create destroyer instance
let destroyer0 = Fighter(name: "Destroyer", weapon: "Laser", remainingFirePower: 10)
print("Destroyer's initial position:", destroyer0.position)
destroyer0.moveRight()
print("Destroyer's position after moving right once:", destroyer0.position)

// 8. Explanation: Printing weapon on falcon won't work because weapon is a property of Fighter class, not Spaceship class. falcon is an instance of Spaceship, so it doesn't have a weapon property.

// 9. Fire from destroyer
destroyer0.fire()
print("Remaining fire power after firing once:", destroyer0.remainingFirePower)

// 11. ShieldedShip class
class ShieldedShip: Fighter {
    var shieldStrength: Int
    
    init(name: String = "", health: Int = 0, position: Int = 0, weapon: String = "", remainingFirePower: Int = 5, shieldStrength: Int = 25) {
        self.shieldStrength = shieldStrength
        super.init(name: name, health: health, position: position, weapon: weapon, remainingFirePower: remainingFirePower)
    }
    
    override func wasHit() {
        if shieldStrength > 0 {
            shieldStrength -= 5
        } else {
            super.wasHit()
        }
    }
}

// 12. Create defender instance
let defender1 = ShieldedShip(name: "Defender", weapon: "Cannon")
defender1.moveRight()
print("Defender's position:", defender1.position)
defender1.fire()
print("Defender's remaining fire power:", defender1.remainingFirePower)

// 13. Calling superclass's wasHit method
defender1.wasHit()
print("Defender's shield strength after being hit once:", defender1.shieldStrength)
print("Defender's health after being hit once:", defender1.health)

// 15. Add initializer to Spaceship
// Already implemented above

// 16. Create falcon instance using memberwise initializer
let falcon1 = Spaceship(name: "Falcon")

// 17. Write initializer for Fighter
// Already implemented above

// 18. Create destroyer instance using memberwise initializer
let destroyer1 = Fighter(name: "Destroyer")

// 19. Write initializer for ShieldedShip
// Already implemented above

// 20. Create defender instance using memberwise initializer
let defender2 = ShieldedShip(name: "Defender")

// 21. Same ship comparison
let sameShip1 = falcon1
print("Position of falcon:", falcon1.position)
print("Position of sameShip:", sameShip1.position)
sameShip1.moveLeft()
print("Position of falcon after moving sameShip:", falcon1.position)
print("Position of sameShip after moving sameShip:", sameShip1.position)
// The positions of both falcon and sameShip changed after moving sameShip. This is because classes are reference types, so assigning falcon to sameShip makes them point to the same instance in memory. If both were structs, it would not be the same because structs are value types, and assigning one to another creates a copy.

// 22. Create registrationList
var registrationList = [String]()

// 23. Add Sara to registrationList
registrationList.append("Sara")
print("Registration List:", registrationList)

// 24. Add four more names
registrationList += ["John", "Alice", "Bob", "Emma"]
print("Registration List after adding more names:", registrationList)

// 25. Insert Charlie into registrationList
registrationList.insert("Charlie", at: 1)
print("Registration List after inserting Charlie:", registrationList)

// 26. Change sixth element to Rebecca
registrationList[5] = "Rebecca"
print("Registration List after changing sixth element:", registrationList)

// 27. Remove last element
let deletedItem = registrationList.removeLast()
print("Deleted item:", deletedItem)

// 28-30. Challenges lists
let walkingChallenges = ["Walk 3 miles a day", "Walk 10,000 steps a day"]
let runningChallenges = ["Run 5 times a week", "Run a half marathon"]
var challenges = [walkingChallenges, runningChallenges]
print("First element in the second challenge list:", challenges[1][0])

// 31. Reset challenges
challenges.removeAll()
print("Challenges after resetting:", challenges)

// 32-33. User committed challenges
var committedChallenges: [String] = []

if committedChallenges.isEmpty {
    print("Please commit to a challenge.")
} else if committedChallenges.count == 1 {
    print("The challenge you have chosen is \(committedChallenges[0])")
} else {
    print("You have chosen multiple challenges.")
}

// 34-37. Days in a month
var daysInMonth = ["January": 31, "February": 28, "March": 31]
print("Dictionary of days in a month:", daysInMonth)

// Add April
daysInMonth["April"] = 30
print("Updated dictionary after adding April:", daysInMonth)

// Update February for leap year
daysInMonth.updateValue(29, forKey: "February")
print("Updated dictionary after leap year:", daysInMonth)

// Retrieve days in January
if let januaryDays = daysInMonth["January"] {
    print("January has \(januaryDays) days")
}

// 38-39. Dictionary of arrays
let shapesArray = ["Circle", "Square", "Triangle"]
let colorsArray = ["Red", "Blue", "Green"]
let dictionaryOfArrays = ["Shapes": shapesArray, "Colors": colorsArray]
print("Dictionary of arrays:", dictionaryOfArrays)
if let lastColor = dictionaryOfArrays["Colors"]?.last {
    print("Last element of colorsArray:", lastColor)
}

// 40-44. Regular paces dictionary
var paces = ["Easy": 10.0, "Medium": 8.0, "Fast": 6.0]
print("Dictionary of regular paces:", paces)

// Add Sprint
paces["Sprint"] = 4.0
print("Dictionary after adding Sprint:", paces)

// Update Medium and Fast paces
paces["Medium"] = 7.5
paces["Fast"] = 5.8
print("Dictionary after updating Medium and Fast paces:", paces)

// Remove Sprint
paces.removeValue(forKey: "Sprint")
print("Dictionary after removing Sprint:", paces)

// 45. Print statement for chosen pace
if let chosenPace = paces["Medium"] {
    print("Okay! I'll keep you at a \(chosenPace) minute mile pace.")
}
