import UIKit

// Q1. Declare two variables, one called `firstDecimal` and one called `secondDecimal`. Both should have decimal values. Look at both of their types by holding Option and clicking the variable name.

let firstDecimal = 3.14
let secondDecimal = 2.718

print(type(of: firstDecimal))
print(type(of: secondDecimal))
print("\n")


// Q2. Declare a variable called `trueOrFalse` and give it a boolean value. Try to assign it to `firstDecimal` like so: `firstDecimal = trueOrFalse`. Does it compile? Print a statement to the console explaining why not, and remove the line of code that will not compile.

let trueOrFalse: Bool = true

// firstDecimal = trueOrFalse

print("Error : Cannot assign a boolean value to a variable explicitly declared as Double.")
print("Explanation : This line will not compile, and you will get an error like Cannot assign value of type 'Bool' to type 'Double'")

print("\n")


// Q3. Declare a variable and give it a string value. Then try to assign it to `firstDecimal`. Does it compile? Print a statement to the console explaining why not, and remove the line of code that will not compile.

let stringValue: String = "Hello"

// firstDecimal = stringValue

print("Error : Cannot assign a string value to a variable explicitly declared as Double.")
print("Explanation : This line will not compile, and you will get an error like Cannot assign value of type 'String' to type 'Double'")

print("\n")

// Q4. Finally, declare a variable with a whole number value. Then try to assign it to `firstDecimal`. Why won't this compile even though both variables are numbers? Print a statement to the console explaining why not, and remove the line of code that will not compile.

let wholeNumberValue: Int = 42

// firstDecimal = wholeNumberValue

print("Error : Cannot assign an integer value to a variable explicitly declared as Double without explicit type conversion.")
print("Explanation : This line will not compile, and you will get an error like Cannot assign value of type 'Int' to type 'Double'")

print("\n")

// Q5. You have declared a number of constants and variables to keep track of fitness information. Declare one more variable with a boolean value called `hasMetStepGoal`.

var hasMetStepGoal: Bool = true
print("\n")

// Q6. When you declared a constant for goal number of steps and a variable for current step count, you likely assigned each a value in the thousands. This can be difficult to read. Redeclare this constant and variable and, when assigning each a value in the thousands, format the number so that it is more readable.

let goalNumberOfSteps: Int = 10_000
var currentStepCount: Int = 2_345
print("\n")


// Q7.Declare a variable called `name` of type `String`, but do not give it a value. Print `name` to the console. Does the code compile? Remove any code that will not compile.

//var name: String
//print(name)

print("Explanation : Variable 'name' is declared but not assigned a value")

print("\n")

// Q8. Declare a variable called `distanceTraveled` and set it to 0. Do not give it an explicit type.

var distanceTraveled = 0

print("\n")

// Q9. Now assign a value of 54.3 to `distanceTraveled`. Does the code compile? Go back and set an explicit type on `distanceTraveled` so the code will compile.

//distanceTraveled: Double = 54.3

print("Explanation : If you try to directly assign 54.3 to distanceTeravlled, the code will not compile because Swift has already inferred distanceTravelled to be of type Int based on the initial assignment of 0. You cannot assign a floating-point value directly to an integer variable without explicit conversion.")

print("\n")

// Q10. You decide that your fitness tracking app should show the user what percentage of his/her goal has been achieved so far today. Declare a variable called percentCompleted and set it to 0. Do not explicity assign it a type.

//var percentCompleted = 0

print("\n")

// Q11. Imagine that partway through the day a user has taken 3,467 steps out of the 10,000 step goal. This means he/she is 34.67% of the way to his/her goal. Assign 34.67 to percentCompleted. Does the code compile? Go back and explicity assign a type to percentCompleted that will allow the code to compile

print("Explanation : If you try to directly assign 34.67 to percentCompleted, the code will not compile because Swift has already inferred percentCompleted to be of type Int based on the initial assignment of 0. You cannot assign a floating-point value directly to an integer variable without explicit conversion.")

var percentCompleted: Double = 34.67


























