import UIKit

// 1. For each of the logical expressions below, print out what you think the resulting value will be (‘true’ or ‘false’). Then print out the actual expression to see if you were right. An example has been provided below.

// a.9==9
let expectedValue1 = true
let actualValue1 = 9 == 9
print("Expected:", expectedValue1)
print("Actual:", actualValue1)

print("\n")

// b.9 != 9
let expectedValue2 = false
let actualValue2 = 9 != 9
print("Expected:", expectedValue2)
print("Actual:", actualValue2)

print("\n")

// c.47>90
let expectedValue3 = false
let actualValue3 = 47>90
print("Expected:", expectedValue3)
print("Actual:", actualValue3)

print("\n")

// d. 47<90
let expectedValue4 = true
let actualValue4 = 47<90
print("Expected:", expectedValue4)
print("Actual:", actualValue4)

print("\n")

// e.4<=4
let expectedValue5 = true
let actualValue5 = 4 <= 4
print("Expected:", expectedValue5)
print("Actual:", actualValue5)

print("\n")

// f.4>=5
let expectedValue6 = true
let actualValue6 = 4 <= 5
print("Expected:", expectedValue6)
print("Actual:", actualValue6)

print("\n")

// g.(47 > 90) && (47 < 90)
let expectedValue7 = false
let actualValue7 = (47 > 90) && (47 < 90)
print("Expected:", expectedValue7)
print("Actual:", actualValue7)

print("\n")

// h.(47>90)||(47<90)
let expectedValue8 = true
let actualValue8 = (47 > 90) || (47 < 90)
print("Expected:", expectedValue8)
print("Actual:", actualValue8)

print("\n")

// i.!true
let expectedValue = false
let actualValue = !true
print("Expected:", expectedValue)
print("Actual:", actualValue)

print("\n")

// 2.Imagine you're creating a machine that will count your money for you and tell you how wealthy you are based on how much money you have. A variable ‘dollars’ has been given to you with a value of 0. Write an if statement that prints "Sorry, kid. You're broke!" if ‘dollars’ has a value of 0. Observe what is printed to the console.

var dollars = 0

if dollars == 0 {
    print("Sorry, kid. You're broke!")
}

print("\n")

// 3.dollars’ has been updated below to have a value of 10. Write an an if-else statement that prints "Sorry, kid. You're broke!" if ‘dollars’ has a value of 0, but prints "You've got some spending money!" otherwise. Observe what is printed to the console.

dollars = 10

if dollars == 0 {
    print("Sorry, kid. You're broke!")
} else {
    print("You've got some spending money!")
}

print("\n")

// 4.‘dollars’ has been updated below to have a value of 105. Write an an if-else-if statement that prints "Sorry, kid. You're broke!" if ‘dollars’ has a value of 0, prints "You've got some spending money!" if ‘dollars’ is less than 100, and prints "Looks to me like you're rich!" otherwise. Observe what is printed to the console.

dollars = 105

if dollars == 0 {
    print("Sorry, kid. You're broke!")
} else if dollars < 100 {
    print("You've got some spending money!")
} else {
    print("Looks to me like you're rich!")
}

print("\n")

// 5.You want your fitness tracking app to give as much encouragement as possible to your users. Create a variable ‘steps’ equal to the number of steps you guess you've taken today. Create a constant ’stepGoal’ equal to 10,000. Write an if-else statement that will print "You're almost halfway there!" if ‘steps’ is less than half of ‘stepGoal’, and will print "You're over halfway there!" if ‘steps’ is greater than half of ‘stepGoal’.

let stepGoal = 10_000
var steps = 6_000

if steps < stepGoal / 2 {
    print("You're almost halfway there!")
} else {
    print("You're over halfway there!")
}

print("\n")

// 6.Now create a new, but similar, if-else-if statement that prints "Way to get a good start today!" if ‘steps’ is less than a tenth of ‘stepGoal’, prints "You're almost halfway there!" if ‘steps’ is less than half of ‘stepGoal’, and prints "You're over halfway there!" if ‘steps’ is greater than half of ‘stepGoal’.

steps = 2_000

if steps < stepGoal / 10 {
    print("Way to get a good start today!")
} else if steps < stepGoal / 2 {
    print("You're almost halfway there!")
} else {
    print("You're over halfway there!")
}

print("\n")

// 7.Imagine you're going to dinner with friends and are struggling to decide where to go. Two of you have very strong opinions and have clearly laid out your requirements for dinner as follows:
//  - You want to eat somewhere that has either fish or pizza - Your friend wants to eat somewhere with vegan options.
//  Another friend brings up a restaurant she thinks will fit both of your criteria. This restaurant's attributes are represented by a few constants below. Write an if-else statement that will print "Let's go!" if the restaurant's attributes match the group's dietary requirements, and otherwise will print "Sorry, we'll have to think of somewhere else."

let hasFish = true
let hasPizza = false
let hasVegan = true

if (hasFish || hasPizza) && hasVegan {
    print("Let's go!")
} else {
    print("Sorry, we'll have to think of somewhere else.")
}

print("\n")

// 8.Imagine you're trying to decide whether or not to go on a walk. You decide that you'll go on a walk if it's not raining or if it's 82 degress or warmer and sunny out. Create a constant ‘isNiceWeather’ that is equal to an expression that evaluates to a boolean indicating whether or not the weather is nice enough for you to go for a walk. Write an if statement that will print "I'm going for a walk!" if the weather is nice.

let temp = 82
let isRaining = true
let isSunny = true

let isNiceWeather = !isRaining || (temp >= 82 && isSunny)

if isNiceWeather {
    print("I'm going for a walk!")
}

print("\n")

// 9.You decide that you want your fitness tracker to have a feature that helps users stay inside specified heart rate zones while they are working out. You'll display a message to the user telling them to go a little faster to increase their heart rate if they are below the target, tell them that they are spot on if they are in the target, and tell them to slow it down a little if they are over the target. Create constants ‘isInTarget’, ‘isBelowTarget’, and ‘isAboveTarget’ that equal expressions that evaluate to whether or not ‘currentHR’ is between the lower and upper bounds, below the lower bound, and above the upper bound, respectively. Then write an if-else-if statement that will print "You're right on track!" if the user is inside the target zone, "You're doing great, but try to push it a bit!" if the user is below the target zone, and "You're on fire! Slow it down just a bit." if the user is above the target zone.

let targetLowerBound = 120
let targetUpperBound = 150
let currentHR1 = 147

let isInTarget = currentHR1 >= targetLowerBound && currentHR1 <= targetUpperBound
let isBelowTarget = currentHR1 < targetLowerBound
let isAboveTarget = currentHR1 > targetUpperBound

if isInTarget {
    print("You're right on track!")
} else if isBelowTarget {
    print("You're doing great, but try to push it a bit!")
} else if isAboveTarget {
    print("You're on fire! Slow it down just a bit.")
}

print("\n")

// 10.Imagine you're on a baseball team nearing the end of the season. Create a ‘leaguePosition’ constant with a value of 1. Using a ‘switch’ statement, print "Champions!" if the ‘leaguePosition’ is 1, "Runners up" if the value is 2, "Third place" if the value is 3, and "Bad season!" in all other cases.

let leaguePosition = 1

switch leaguePosition {
case 1:
    print("Champions!")
case 2:
    print("Runners up")
case 3:
    print("Third place")
default:
    print("Bad season!")
}

print("\n")

// 11.Write a new ‘switch’ statement that prints "Medal winner" if ‘leaguePosition’ is within the range of 1-3. Otherwise, print "No medal awarded."

switch leaguePosition {
case 1...3:
    print("Medal winner")
default:
    print("No medal awarded.")
}

print("\n")

// 12.If you completed the Target Heart Rate exercise, you showed different statements to the user based on whether or not the user's heart rate was inside of a target zone. Now you decide to just tell them what zone they are in rather than tell them what zone to be in.
//  Write a switch statement that will print different statements based on what range ‘currentHR’ falls into. Below is a list of ranges and the associated statements
// - 100-120: "You are in the Very Light zone. Activity in this zone helps with recovery."
// - 121-140: "You are in the Light zone. Activity in this zone helps improve basice endurance and fat burning."
// - 141-160: "You are in the Moderate zone. Activity in this zone helps improve aerobic fitness." - 161-180: "You are in the Hard zone. Activity in this zone increases maximum performance capacity for shorter sessions."
// - 181-200: "You are in the Maximum zone. Activity in this zone helps fit athletes develop speed."

switch currentHR1 {
case 100...120:
    print("You are in the Very Light zone. Activity in this zone helps with recovery.")
case 121...140:
    print("You are in the Light zone. Activity in this zone helps improve basic endurance and fat burning.")
case 141...160:
    print("You are in the Moderate zone. Activity in this zone helps improve aerobic fitness.")
case 161...180:
    print("You are in the Hard zone. Activity in this zone increases maximum performance capacity for shorter sessions.")
case 181...200:
    print("You are in the Maximum zone. Activity in this zone helps fit athletes develop speed.")
default:
    print("Heart rate zone not defined.")
}

print("\n")

// 13.If ‘currentHR’ is above the listed zones, print some kind of warning asking the user to slow down.

let currentHR = 128

switch currentHR {
case 100...120:
    print("You are in the Very Light zone. Activity in this zone helps with recovery.")
case 121...140:
    print("You are in the Light zone. Activity in this zone helps improve basic endurance and fat burning.")
case 141...160:
    print("You are in the Moderate zone. Activity in this zone helps improve aerobic fitness.")
case 161...180:
    print("You are in the Hard zone. Activity in this zone increases maximum performance capacity for shorter sessions.")
case 181...200:
    print("You are in the Maximum zone. Activity in this zone helps fit athletes develop speed.")
default:
    if currentHR > 200 {
        print("Warning: Your heart rate is very high. Please slow down and consult with a healthcare professional.")
    } else {
        print("Heart rate zone not defined.")
    }
}

// 14.Refactor the code below so that `largest` is declared and assigned to in one line using the ternary operator.

let number1 = 14
let number2 = 25
let largest = (number1 > number2) ? number1 : number2

print("\n")


// 15.The code below should look similar to code you wrote in the Fitness Decisions exercise. The if-else statement is actually unnecessary, and instead you can print either one statement or the other all on one line using the ternary operator. Go ahead and refactor the code below to do just that.

let stepGoal1 = 10000
let steps1 = 3948

print(steps1 < stepGoal1 / 2 ? "Almost halfway!" : "Over halfway!")








                                                                                                        
                                                                                                        















