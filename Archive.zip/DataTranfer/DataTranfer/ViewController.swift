//
//  ViewController.swift
//  DataTranfer
//
//  Created by Apple Lab 27 on 27/04/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var nameInput: UITextField!
    
    @IBOutlet var nameError: UILabel!
    
    
    
    @IBOutlet var emailInput: UITextField!
    
    @IBOutlet var emailError: UILabel!
    
    
    
    @IBOutlet var MobileError: UILabel!
    
    @IBOutlet var mobInput: UITextField!
    
    
    @IBOutlet var passwordError: UILabel!
    
    @IBOutlet var passInput: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitInput(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DataDetailViewController") as! DataDetailViewController
        
        vc.name = nameInput.text!
        vc.email = emailInput.text!
        vc.mob = mobInput.text!
        vc.pass = passInput.text!
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}

