//
//  DataDetailViewController.swift
//  DataTranfer
//
//  Created by Apple Lab 27 on 27/04/24.
//

import UIKit

class DataDetailViewController: UIViewController {

    @IBOutlet var nameLabel: UILabel!
    
    @IBOutlet var emailLabel: UILabel!
    
    @IBOutlet var mobileLabel: UILabel!
    
    @IBOutlet var passLabel: UILabel!
    
    var name = ""
    var email = ""
    var mob = ""
    var pass = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameLabel.text = " \(name)"
        emailLabel.text = " \(email)"
        mobileLabel.text = " \(mob)"
        passLabel.text = " \(pass)" 
    }

}
