//
//  ViewController.swift
//  TabBarView
//
//  Created by Apple Lab 27 on 27/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

