//
//  ViewController.swift
//  Nav & segues controler
//
//  Created by Apple Lab 11 on 18/04/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    

}

