// SkillsView.swift
import SwiftUI

struct SkillsView: View {
    let skills = ["iOS Development", "SwiftUI", "Machine Learning", "UI/UX Design", "Product Management"]
    
    var body: some View {
        VStack {
            Text("Skills")
                .font(.title)
            ForEach(skills, id: \.self) { skill in
                Text(skill)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
    }
}
