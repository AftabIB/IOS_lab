


import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            ProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
            SkillsView()
                .tabItem {
                    Image(systemName: "star.fill")
                    Text("Skills")
                }
            InterestsView()
                .tabItem {
                    Image(systemName: "heart.fill")
                    Text("Interests")
                }
        }
    }
}
