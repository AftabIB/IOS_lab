// InterestsView.swift
import SwiftUI

struct InterestsView: View {
    let interests = ["Reading", "Hiking", "Photography", "Cooking", "Traveling"]
    
    var body: some View {
        VStack {
            Text("Interests")
                .font(.title)
            ForEach(interests, id: \.self) { interest in
                Text(interest)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
    }
}
