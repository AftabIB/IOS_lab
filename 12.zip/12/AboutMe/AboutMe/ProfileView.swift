// ProfileView.swift
import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack {
            Image("Image")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 200, height: 200)
                .clipShape(Circle())
                .padding()
            Text("Aftab Bhadgaonkar")
                .font(.title)
            Text("Hello Everyone, My name is Aftab Bhadgaonkar. I am from Walchand College of Engineering, Sangli. TY CSE Student")
                .font(.subheadline)
                .foregroundColor(.gray)

        }
    }
}
