//
//  AboutMeApp.swift
//  AboutMe
//
//  Created by Apple Lab 3 on 18/04/24.
//

import SwiftUI

@main
struct AboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
