//
//  ViewController.swift
//  Calculator
//
//  Created by Apple Lab 27 on 26/04/24.
//

import UIKit

class ViewController: UIViewController {

    
        
    @IBOutlet weak var calculatorWorking : UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

